"""
models.py - Data models and schema definitions for Campus Catalyst Contact Book.
"""

from dataclasses import dataclass, asdict, field
from datetime import datetime
import uuid
from typing import Dict, Any, Optional

VALID_CATEGORIES = {"Academic", "Professional", "Personal", "Emergency", "Student", "Other"}
VALID_STATUSES = {"Active", "Archived", "Pending"}

@dataclass
class Contact:
    id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    name: str = ""
    phone: str = ""
    email: str = ""
    category: str = "Academic"
    notes: str = ""
    status: str = "Active"
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    updated_at: str = field(default_factory=lambda: datetime.now().isoformat())

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Contact":
        # Ensure default values for missing keys
        valid_keys = {f.name for f in cls.__dataclass_fields__.values()}
        filtered_data = {k: v for k, v in data.items() if k in valid_keys}
        return cls(**filtered_data)
