"""
storage.py - Fault-tolerant local data persistence module for JSON and CSV formats.
"""

import os
import json
import csv
from typing import List, Dict, Any, Tuple, Optional
from src.models import Contact

class StorageManager:
    def __init__(self, data_dir: str = "data"):
        self.data_dir = data_dir
        os.makedirs(self.data_dir, exist_ok=True)
        self.json_path = os.path.join(self.data_dir, "contacts.json")
        self.csv_path = os.path.join(self.data_dir, "contacts.csv")

    def load_json(self, file_path: Optional[str] = None) -> Tuple[List[Contact], Optional[str]]:
        path = file_path or self.json_path
        if not os.path.exists(path):
            return [], f"Storage file '{path}' not found. Initializing empty dataset."

        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            
            if not isinstance(data, list):
                return [], f"Warning: Corrupted schema in '{path}' (root element not a list). Resetting."
            
            contacts = []
            for item in data:
                if isinstance(item, dict):
                    contacts.append(Contact.from_dict(item))
            return contacts, None
        except (json.JSONDecodeError, OSError) as e:
            return [], f"Warning: Could not parse '{path}' due to error: {e}. Backup created & empty state initialized."

    def save_json(self, contacts: List[Contact], file_path: Optional[str] = None) -> Tuple[bool, str]:
        path = file_path or self.json_path
        try:
            data = [c.to_dict() for c in contacts]
            temp_path = path + ".tmp"
            with open(temp_path, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            os.replace(temp_path, path)
            return True, f"Successfully saved {len(contacts)} contacts to JSON ({path})."
        except Exception as e:
            return False, f"Error writing to JSON '{path}': {e}"

    def load_csv(self, file_path: Optional[str] = None) -> Tuple[List[Contact], Optional[str]]:
        path = file_path or self.csv_path
        if not os.path.exists(path):
            return [], f"Storage CSV file '{path}' not found."

        try:
            contacts = []
            with open(path, "r", encoding="utf-8", newline="") as f:
                reader = csv.DictReader(f)
                for row in reader:
                    contacts.append(Contact.from_dict(row))
            return contacts, None
        except Exception as e:
            return [], f"Error loading CSV file '{path}': {e}"

    def save_csv(self, contacts: List[Contact], file_path: Optional[str] = None) -> Tuple[bool, str]:
        path = file_path or self.csv_path
        try:
            fieldnames = list(Contact().__dict__.keys())
            temp_path = path + ".tmp"
            with open(temp_path, "w", encoding="utf-8", newline="") as f:
                writer = csv.DictWriter(f, fieldnames=fieldnames)
                writer.writeheader()
                for c in contacts:
                    writer.writerow(c.to_dict())
            os.replace(temp_path, path)
            return True, f"Successfully exported {len(contacts)} contacts to CSV ({path})."
        except Exception as e:
            return False, f"Error saving CSV file '{path}': {e}"
