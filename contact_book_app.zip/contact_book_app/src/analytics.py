"""
analytics.py - Executive summary generation, metrics calculation, and multi-format export routines.
"""

from typing import List, Dict, Any, Tuple
from collections import Counter
from datetime import datetime
import os
import csv
from src.models import Contact

class ContactAnalytics:
    def __init__(self, contacts: List[Contact]):
        self.contacts = contacts

    def generate_summary_metrics(self) -> Dict[str, Any]:
        total = len(self.contacts)
        category_counts = Counter(c.category for c in self.contacts)
        status_counts = Counter(c.status for c in self.contacts)
        
        missing_notes_count = sum(1 for c in self.contacts if not c.notes or not c.notes.strip())
        edu_emails_count = sum(1 for c in self.contacts if c.email.endswith(".edu"))
        
        warnings = []
        if total == 0:
            warnings.append("CRITICAL: Contact database is empty.")
        if status_counts.get("Archived", 0) > total * 0.4 and total > 0:
            warnings.append("WARNING: High proportion of contacts (>40%) are Archived.")
        if missing_notes_count > total * 0.5 and total > 0:
            warnings.append("NOTICE: Over 50% of contact entries have empty notes.")

        return {
            "total_contacts": total,
            "category_breakdown": dict(category_counts),
            "status_breakdown": dict(status_counts),
            "edu_domain_contacts": edu_emails_count,
            "missing_notes_count": missing_notes_count,
            "warnings": warnings,
            "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }

    def format_terminal_summary(self) -> str:
        metrics = self.generate_summary_metrics()
        
        lines = []
        lines.append("=" * 65)
        lines.append("        CAMPUS CATALYST CONTACT BOOK - EXECUTIVE SUMMARY")
        lines.append("=" * 65)
        lines.append(f" Generated At       : {metrics['generated_at']}")
        lines.append(f" Total Records      : {metrics['total_contacts']}")
        lines.append(f" .edu Campus Emails : {metrics['edu_domain_contacts']}")
        lines.append("-" * 65)
        lines.append(" CATEGORY BREAKDOWN:")
        for cat, count in metrics["category_breakdown"].items():
            pct = (count / metrics['total_contacts'] * 100) if metrics['total_contacts'] > 0 else 0
            lines.append(f"   • {cat:<15}: {count:>3} records ({pct:>5.1f}%)")
        lines.append("-" * 65)
        lines.append(" STATUS BREAKDOWN:")
        for stat, count in metrics["status_breakdown"].items():
            pct = (count / metrics['total_contacts'] * 100) if metrics['total_contacts'] > 0 else 0
            lines.append(f"   • {stat:<15}: {count:>3} records ({pct:>5.1f}%)")
        lines.append("-" * 65)
        if metrics["warnings"]:
            lines.append(" THRESHOLD & AUDIT WARNINGS:")
            for w in metrics["warnings"]:
                lines.append(f"   [!] {w}")
            lines.append("-" * 65)
        lines.append("=" * 65)
        return "\n".join(lines)

    def export_markdown_report(self, filepath: str) -> bool:
        metrics = self.generate_summary_metrics()
        try:
            with open(filepath, "w", encoding="utf-8") as f:
                f.write("# Campus Catalyst: Contact Book Executive Summary\n\n")
                f.write(f"**Generated:** {metrics['generated_at']}  \n")
                f.write(f"**Total Records:** {metrics['total_contacts']}  \n")
                f.write(f"**Campus .edu Emails:** {metrics['edu_domain_contacts']}\n\n")
                
                f.write("## Category Breakdown\n\n")
                f.write("| Category | Count | Percentage |\n")
                f.write("| --- | --- | --- |\n")
                for cat, count in metrics["category_breakdown"].items():
                    pct = (count / metrics['total_contacts'] * 100) if metrics['total_contacts'] > 0 else 0
                    f.write(f"| {cat} | {count} | {pct:.1f}%\n")
                
                f.write("\n## Status Distribution\n\n")
                f.write("| Status | Count | Percentage |\n")
                f.write("| --- | --- | --- |\n")
                for stat, count in metrics["status_breakdown"].items():
                    pct = (count / metrics['total_contacts'] * 100) if metrics['total_contacts'] > 0 else 0
                    f.write(f"| {stat} | {count} | {pct:.1f}%\n")

                if metrics["warnings"]:
                    f.write("\n## Threshold Warnings & Audit Flags\n\n")
                    for w in metrics["warnings"]:
                        f.write(f"- ⚠️ **{w}**\n")
            return True
        except Exception:
            return False

    def export_csv_summary(self, filepath: str) -> bool:
        try:
            fieldnames = ["id", "name", "phone", "email", "category", "status", "notes", "created_at"]
            with open(filepath, "w", encoding="utf-8", newline="") as f:
                writer = csv.DictWriter(f, fieldnames=fieldnames)
                writer.writeheader()
                for c in self.contacts:
                    row = c.to_dict()
                    writer.writerow({k: row.get(k, "") for k in fieldnames})
            return True
        except Exception:
            return False
