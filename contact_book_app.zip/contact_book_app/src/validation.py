"""
validation.py - Defensive input sanitization and validation utilities.
"""

import re
from typing import Tuple, Optional
from src.models import VALID_CATEGORIES, VALID_STATUSES

PHONE_REGEX = re.compile(r"^\+?[0-9\s\-\(\)]{7,20}$")
EMAIL_REGEX = re.compile(r"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$")

def validate_name(name: str) -> Tuple[bool, str]:
    cleaned = name.strip()
    if not cleaned:
        return False, "Name cannot be empty or purely whitespace."
    if len(cleaned) < 2:
        return False, "Name must be at least 2 characters long."
    if len(cleaned) > 100:
        return False, "Name exceeds maximum length of 100 characters."
    return True, cleaned

def validate_phone(phone: str) -> Tuple[bool, str]:
    cleaned = phone.strip()
    if not cleaned:
        return False, "Phone number cannot be empty."
    # Strip spaces and hyphens for digit count check
    digits_only = re.sub(r"\D", "", cleaned)
    if len(digits_only) < 7 or len(digits_only) > 15:
        return False, "Phone number must contain between 7 and 15 digits."
    if not PHONE_REGEX.match(cleaned):
        return False, "Invalid phone number format (e.g., +1-555-0199 or 555-0199)."
    return True, cleaned

def validate_email(email: str) -> Tuple[bool, str]:
    cleaned = email.strip().lower()
    if not cleaned:
        return False, "Email address cannot be empty."
    if not EMAIL_REGEX.match(cleaned):
        return False, "Invalid email address format (e.g., user@campus.edu)."
    return True, cleaned

def validate_category(category: str) -> Tuple[bool, str]:
    cleaned = category.strip().capitalize()
    # Case insensitive match against valid categories
    matched = next((cat for cat in VALID_CATEGORIES if cat.lower() == cleaned.lower()), None)
    if not matched:
        cats_formatted = ", ".join(sorted(VALID_CATEGORIES))
        return False, f"Invalid category. Allowed categories: {cats_formatted}"
    return True, matched

def validate_status(status: str) -> Tuple[bool, str]:
    cleaned = status.strip().capitalize()
    matched = next((s for s in VALID_STATUSES if s.lower() == cleaned.lower()), None)
    if not matched:
        statuses_formatted = ", ".join(sorted(VALID_STATUSES))
        return False, f"Invalid status. Allowed statuses: {statuses_formatted}"
    return True, matched
