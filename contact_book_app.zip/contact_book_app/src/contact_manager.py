"""
contact_manager.py - Core Business Logic Engine for Campus Catalyst Contact Book.
"""

from typing import List, Optional, Dict, Any, Tuple
from datetime import datetime
from src.models import Contact
from src.validation import (
    validate_name, validate_phone, validate_email, 
    validate_category, validate_status
)

class ContactManager:
    def __init__(self, contacts: Optional[List[Contact]] = None):
        self.contacts: List[Contact] = contacts if contacts is not None else []

    def add_contact(self, name: str, phone: str, email: str, 
                    category: str = "Academic", notes: str = "", status: str = "Active") -> Tuple[bool, str, Optional[Contact]]:
        # Defensive Input Validation
        v_name, msg_name = validate_name(name)
        if not v_name:
            return False, f"Name Error: {msg_name}", None

        v_phone, msg_phone = validate_phone(phone)
        if not v_phone:
            return False, f"Phone Error: {msg_phone}", None

        v_email, msg_email = validate_email(email)
        if not v_email:
            return False, f"Email Error: {msg_email}", None

        v_cat, msg_cat = validate_category(category)
        if not v_cat:
            return False, f"Category Error: {msg_cat}", None

        v_stat, msg_stat = validate_status(status)
        if not v_stat:
            return False, f"Status Error: {msg_stat}", None

        # Check for duplicate email or phone (warning / check)
        for c in self.contacts:
            if c.email.lower() == msg_email.lower():
                return False, f"Duplicate Entry: A contact with email '{msg_email}' already exists.", None

        new_contact = Contact(
            name=msg_name,
            phone=msg_phone,
            email=msg_email,
            category=msg_cat,
            notes=notes.strip(),
            status=msg_stat
        )
        self.contacts.append(new_contact)
        return True, f"Contact '{new_contact.name}' (ID: {new_contact.id}) successfully added.", new_contact

    def edit_contact(self, contact_id: str, updates: Dict[str, str]) -> Tuple[bool, str, Optional[Contact]]:
        contact = self.get_by_id(contact_id)
        if not contact:
            return False, f"Contact with ID '{contact_id}' not found.", None

        # Validate updates
        if "name" in updates and updates["name"].strip():
            v, msg = validate_name(updates["name"])
            if not v:
                return False, f"Name Error: {msg}", None
            contact.name = msg

        if "phone" in updates and updates["phone"].strip():
            v, msg = validate_phone(updates["phone"])
            if not v:
                return False, f"Phone Error: {msg}", None
            contact.phone = msg

        if "email" in updates and updates["email"].strip():
            v, msg = validate_email(updates["email"])
            if not v:
                return False, f"Email Error: {msg}", None
            # Check duplicate email if changed
            if msg.lower() != contact.email.lower():
                for c in self.contacts:
                    if c.id != contact_id and c.email.lower() == msg.lower():
                        return False, f"Duplicate Entry: Email '{msg}' is already in use.", None
            contact.email = msg

        if "category" in updates and updates["category"].strip():
            v, msg = validate_category(updates["category"])
            if not v:
                return False, f"Category Error: {msg}", None
            contact.category = msg

        if "status" in updates and updates["status"].strip():
            v, msg = validate_status(updates["status"])
            if not v:
                return False, f"Status Error: {msg}", None
            contact.status = msg

        if "notes" in updates:
            contact.notes = updates["notes"].strip()

        contact.updated_at = datetime.now().isoformat()
        return True, f"Contact '{contact.name}' updated successfully.", contact

    def delete_contact(self, contact_id: str) -> Tuple[bool, str]:
        contact = self.get_by_id(contact_id)
        if not contact:
            return False, f"Contact with ID '{contact_id}' not found."
        self.contacts = [c for c in self.contacts if c.id != contact_id]
        return True, f"Contact '{contact.name}' (ID: {contact_id}) deleted successfully."

    def get_by_id(self, contact_id: str) -> Optional[Contact]:
        for c in self.contacts:
            if c.id == contact_id or c.id.lower() == contact_id.lower():
                return c
        return None

    def search_contacts(self, query: str, category: Optional[str] = None, status: Optional[str] = None) -> List[Contact]:
        query_lower = query.strip().lower()
        results = []

        for c in self.contacts:
            # Keyword match across name, email, phone, notes, category
            match_query = (
                not query_lower or
                query_lower in c.name.lower() or
                query_lower in c.email.lower() or
                query_lower in c.phone.lower() or
                query_lower in c.notes.lower() or
                query_lower in c.category.lower()
            )
            match_category = not category or c.category.lower() == category.lower()
            match_status = not status or c.status.lower() == status.lower()

            if match_query and match_category and match_status:
                results.append(c)
        return results

    def bulk_import(self, new_contacts: List[Contact]) -> Tuple[int, int, List[str]]:
        imported = 0
        skipped = 0
        logs = []

        existing_emails = {c.email.lower() for c in self.contacts}

        for idx, c in enumerate(new_contacts, 1):
            if c.email.lower() in existing_emails:
                skipped += 1
                logs.append(f"Row {idx}: Skipped duplicate email '{c.email}'.")
                continue

            v_name, _ = validate_name(c.name)
            v_phone, _ = validate_phone(c.phone)
            v_email, _ = validate_email(c.email)

            if v_name and v_phone and v_email:
                self.contacts.append(c)
                existing_emails.add(c.email.lower())
                imported += 1
            else:
                skipped += 1
                logs.append(f"Row {idx}: Invalid fields for '{c.name}'.")

        return imported, skipped, logs
