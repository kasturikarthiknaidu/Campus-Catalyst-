#!/usr/bin/env python3
"""
main.py - Interactive CLI interface for Campus Catalyst Contact Book.
Hackathon Demo Entry Point.
"""

import sys
import os
from typing import Optional

# Add project root to sys.path
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))

from src.storage import StorageManager
from src.contact_manager import ContactManager
from src.analytics import ContactAnalytics
from src.models import VALID_CATEGORIES, VALID_STATUSES

# ANSI Color Codes for branded terminal interface
BLUE = "\033[94m"
GREEN = "\033[92m"
YELLOW = "\033[93m"
RED = "\033[91m"
BOLD = "\033[1m"
RESET = "\033[0m"

def print_banner():
    print(f"{BLUE}{BOLD}")
    print("=================================================================")
    print("       CAMPUS CATALYST: PYTHON CONTACT BOOK UTILITY             ")
    print("            Digital Tools & Productivity Suite                  ")
    print("=================================================================")
    print(f"{RESET}")

def print_menu():
    print(f"\n{BOLD}--- MAIN MENU ---{RESET}")
    print(f" {GREEN}1.{RESET} View All Contacts")
    print(f" {GREEN}2.{RESET} Add New Contact (With Validation)")
    print(f" {GREEN}3.{RESET} Search / Filter Contacts")
    print(f" {GREEN}4.{RESET} Edit Existing Contact")
    print(f" {GREEN}5.{RESET} Delete Contact")
    print(f" {GREEN}6.{RESET} Executive Summary & Metrics Analytics")
    print(f" {GREEN}7.{RESET} Export Summary Reports (Markdown / CSV)")
    print(f" {GREEN}8.{RESET} Save Data (JSON & CSV)")
    print(f" {GREEN}9.{RESET} Exit Application")

def main():
    print_banner()
    storage = StorageManager(data_dir="data")
    
    # Auto-load on startup
    contacts, load_msg = storage.load_json()
    if load_msg:
        # Fallback to CSV if JSON not available
        contacts_csv, csv_msg = storage.load_csv()
        if contacts_csv:
            contacts = contacts_csv
            print(f"{GREEN}[+] Loaded dataset from CSV.{RESET}")
        else:
            print(f"{YELLOW}[!] {load_msg}{RESET}")
    else:
        print(f"{GREEN}[+] Loaded {len(contacts)} contacts from JSON storage.{RESET}")

    manager = ContactManager(contacts)

    while True:
        print_menu()
        choice = input(f"\n{BOLD}Select an option (1-9): {RESET}").strip()

        if choice == "1":
            results = manager.contacts
            if not results:
                print(f"{YELLOW}No contacts found in database.{RESET}")
            else:
                print(f"\n{BOLD}{'ID':<10} {'Name':<22} {'Phone':<15} {'Category':<14} {'Status':<10}{RESET}")
                print("-" * 75)
                for c in results:
                    print(f"{c.id:<10} {c.name[:20]:<22} {c.phone:<15} {c.category:<14} {c.status:<10}")
                print("-" * 75)
                print(f"Total: {len(results)} records.")

        elif choice == "2":
            print(f"\n{BOLD}--- Add New Contact ---{RESET}")
            name = input("Enter Full Name: ")
            phone = input("Enter Phone Number (e.g. +1-555-0199): ")
            email = input("Enter Email Address: ")
            print(f"Categories: {', '.join(sorted(VALID_CATEGORIES))}")
            category = input("Enter Category [Academic]: ").strip() or "Academic"
            print(f"Statuses: {', '.join(sorted(VALID_STATUSES))}")
            status = input("Enter Status [Active]: ").strip() or "Active"
            notes = input("Enter Notes (optional): ")

            success, msg, contact = manager.add_contact(name, phone, email, category, notes, status)
            if success:
                print(f"{GREEN}[+] {msg}{RESET}")
                storage.save_json(manager.contacts)
            else:
                print(f"{RED}[-] Validation Failed: {msg}{RESET}")

        elif choice == "3":
            print(f"\n{BOLD}--- Search Contacts ---{RESET}")
            q = input("Enter keyword search (Name, Email, Phone, Category, Notes): ")
            cat_filter = input("Filter by Category (leave blank for all): ").strip() or None
            stat_filter = input("Filter by Status (leave blank for all): ").strip() or None
            
            matches = manager.search_contacts(q, cat_filter, stat_filter)
            print(f"\n{GREEN}Found {len(matches)} matching record(s):{RESET}")
            for c in matches:
                print(f"\n  • ID: {c.id} | Name: {c.name}")
                print(f"    Phone: {c.phone} | Email: {c.email}")
                print(f"    Category: {c.category} | Status: {c.status}")
                if c.notes:
                    print(f"    Notes: {c.notes}")

        elif choice == "4":
            print(f"\n{BOLD}--- Edit Contact ---{RESET}")
            cid = input("Enter Contact ID to edit: ").strip()
            c = manager.get_by_id(cid)
            if not c:
                print(f"{RED}[-] Contact not found.{RESET}")
                continue
            
            print(f"Editing Contact '{c.name}'. Press Enter to keep current value.")
            new_name = input(f"Name [{c.name}]: ")
            new_phone = input(f"Phone [{c.phone}]: ")
            new_email = input(f"Email [{c.email}]: ")
            new_cat = input(f"Category [{c.category}]: ")
            new_stat = input(f"Status [{c.status}]: ")
            new_notes = input(f"Notes [{c.notes}]: ")

            updates = {}
            if new_name.strip(): updates["name"] = new_name
            if new_phone.strip(): updates["phone"] = new_phone
            if new_email.strip(): updates["email"] = new_email
            if new_cat.strip(): updates["category"] = new_cat
            if new_stat.strip(): updates["status"] = new_stat
            if new_notes.strip(): updates["notes"] = new_notes

            success, msg, _ = manager.edit_contact(cid, updates)
            if success:
                print(f"{GREEN}[+] {msg}{RESET}")
                storage.save_json(manager.contacts)
            else:
                print(f"{RED}[-] Update failed: {msg}{RESET}")

        elif choice == "5":
            print(f"\n{BOLD}--- Delete Contact ---{RESET}")
            cid = input("Enter Contact ID to delete: ").strip()
            confirm = input(f"Are you sure you want to delete contact ID '{cid}'? (y/N): ").lower()
            if confirm == 'y':
                success, msg = manager.delete_contact(cid)
                if success:
                    print(f"{GREEN}[+] {msg}{RESET}")
                    storage.save_json(manager.contacts)
                else:
                    print(f"{RED}[-] {msg}{RESET}")

        elif choice == "6":
            analytics = ContactAnalytics(manager.contacts)
            print("\n" + analytics.format_terminal_summary())

        elif choice == "7":
            print(f"\n{BOLD}--- Export Reports ---{RESET}")
            analytics = ContactAnalytics(manager.contacts)
            md_path = os.path.join("data", "summary_report.md")
            csv_path = os.path.join("data", "exported_contacts.csv")
            
            if analytics.export_markdown_report(md_path):
                print(f"{GREEN}[+] Exported Executive Summary to '{md_path}'.{RESET}")
            if analytics.export_csv_summary(csv_path):
                print(f"{GREEN}[+] Exported CSV dataset report to '{csv_path}'.{RESET}")

        elif choice == "8":
            json_ok, json_msg = storage.save_json(manager.contacts)
            csv_ok, csv_msg = storage.save_csv(manager.contacts)
            print(f"{GREEN}[+] {json_msg}{RESET}")
            print(f"{GREEN}[+] {csv_msg}{RESET}")

        elif choice == "9":
            # Save before exit
            storage.save_json(manager.contacts)
            storage.save_csv(manager.contacts)
            print(f"\n{BLUE}Thank you for using Campus Catalyst Contact Book! Goodbye.{RESET}\n")
            break

        else:
            print(f"{RED}Invalid selection. Please choose options 1 through 9.{RESET}")

if __name__ == "__main__":
    main()
