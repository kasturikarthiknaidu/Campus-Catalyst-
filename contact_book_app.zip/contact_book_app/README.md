# Campus Catalyst: Python Contact Book Development Guide
**Project #108: Contact Book | Domain: Digital Tools & Productivity | Hackathon Mentor Guide**

---

## 📌 Executive Overview
**Campus Catalyst Contact Book** is a modular, fault-tolerant Python terminal application designed for rapid local contact management, robust entry validation, multi-format JSON/CSV persistence, and executive summary analytics. 

Developed specifically for campus stakeholders, hackathon teams, and productivity workflows, it eliminates calculation errors, misplaced entries, and input friction without requiring enterprise database infrastructure or external third-party software dependencies.

---

## 🚀 Key Features

### 1. Interactive Terminal Interface (`main.py`)
- Menu-driven prompt navigation with ANSI color coding.
- User-guided workflow for adding, editing, querying, and analyzing contacts.

### 2. Defensive Input Validation (`src/validation.py`)
- Real-time regex and range validation for Phone numbers (`+1-555-0101`) and Email addresses (`.edu` domain enforcement support).
- Standardized Category (`Academic`, `Student`, `Professional`, `Emergency`, `Personal`) and Status (`Active`, `Archived`, `Pending`) enforcement.
- Unique constraint checks preventing accidental duplicate email creations.

### 3. Core Business Logic Engine (`src/contact_manager.py`)
- Full CRUD (Create, Read, Update, Delete) capability.
- Flexible keyword and multi-attribute search filtering (Name, Email, Phone, Category, Notes, Status).
- Bulk dataset ingestion with automatic format validation and row error logging.

### 4. Local Data Persistence (`src/storage.py`)
- Dual JSON & CSV automated read/write module.
- Schema verification and automatic self-healing fallback when storage files are missing or corrupted.

### 5. Executive Summary & Audit Analytics (`src/analytics.py`)
- Instant calculation of total records, category distribution, and campus `.edu` ratio.
- Automated threshold warning indicators (e.g. empty database, high archived ratio, missing notes audit).
- Export capability generating formatted Markdown reports (`summary_report.md`) and standardized CSV audit files.

---

## 📁 Package Structure

```
contact_book_app/
├── README.md                 # Detailed documentation & setup guide
├── requirements.txt          # Zero-dependency specification (Standard Library only)
├── main.py                   # Interactive CLI application entry point
├── src/                      # Core application source modules
│   ├── __init__.py
│   ├── models.py             # Dataclass models & schema definitions
│   ├── validation.py         # Defensive input sanitization & regex rules
│   ├── storage.py            # JSON & CSV fault-tolerant persistence engine
│   ├── contact_manager.py    # Business logic CRUD & multi-field search engine
│   └── analytics.py          # Summary metrics, warning flags & report export
├── data/                     # Local data storage & sample datasets
│   ├── sample_contacts.json  # 30 pre-loaded realistic campus records (JSON)
│   ├── sample_contacts.csv   # 30 pre-loaded realistic campus records (CSV)
│   ├── contacts.json         # Active JSON storage file
│   └── contacts.csv          # Active CSV storage file
└── tests/                    # Automated testing suite
    └── test_contact_book.py  # Unit tests for validation, CRUD, storage & analytics
```

---

## 🛠️ Quickstart Instructions

### Prerequisites
- **Python 3.10** or higher.
- No `pip install` required — runs entirely on Python's Standard Library!

### Running the Application
From the `contact_book_app` folder, launch the application:

```bash
python3 main.py
```

### Running Automated Tests
To run the automated unit test suite:

```bash
python3 -m unittest discover -s tests
```

---

## 🎯 Hackathon Demo Walkthrough

1. **Launch App**: Run `python3 main.py`. Notice the welcome banner and auto-loading of 30 sample campus records.
2. **View Contacts**: Option `1` displays formatted tabular record lists.
3. **Defensive Validation Demo**: Option `2` — try entering an invalid phone (`123`) or invalid email (`user@invalid`). Watch real-time input sanitization prevent invalid entries.
4. **Keyword Search**: Option `3` — search for `"Academic"` or `"Dr. Vance"`.
5. **Executive Summary**: Option `6` — generates real-time analytics with category percentages and threshold warning checks.
6. **Report Export**: Option `7` — exports `data/summary_report.md` and `data/exported_contacts.csv`.
7. **Verify Persistence**: Option `9` to exit, then relaunch `python3 main.py` to confirm state preservation.

---

*Campus Catalyst #108 - Digital Tools & Productivity Hackathon Suite*
