"""
test_contact_book.py - Suite of unit tests for Campus Catalyst Contact Book.
"""

import unittest
import os
import shutil
import tempfile
import json
import sys

# Add project root to sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from src.models import Contact
from src.validation import validate_name, validate_phone, validate_email, validate_category, validate_status
from src.storage import StorageManager
from src.contact_manager import ContactManager
from src.analytics import ContactAnalytics

class TestContactBook(unittest.TestCase):

    def setUp(self):
        self.test_dir = tempfile.mkdtemp()
        self.storage = StorageManager(data_dir=self.test_dir)
        self.manager = ContactManager()

    def tearDown(self):
        shutil.rmtree(self.test_dir)

    def test_validation_rules(self):
        # Name validation
        ok, _ = validate_name("Dr. Eleanor Vance")
        self.assertTrue(ok)
        ok, _ = validate_name("")
        self.assertFalse(ok)

        # Phone validation
        ok, _ = validate_phone("+1-555-0101")
        self.assertTrue(ok)
        ok, _ = validate_phone("invalid-phone")
        self.assertFalse(ok)

        # Email validation
        ok, _ = validate_email("user@campus.edu")
        self.assertTrue(ok)
        ok, _ = validate_email("not-an-email")
        self.assertFalse(ok)

        # Category validation
        ok, cat = validate_category("academic")
        self.assertTrue(ok)
        self.assertEqual(cat, "Academic")

        ok, _ = validate_category("InvalidCategory")
        self.assertFalse(ok)

    def test_contact_manager_crud(self):
        # Add Contact
        ok, msg, contact = self.manager.add_contact(
            name="Alice Smith",
            phone="+1-555-0199",
            email="asmith@campus.edu",
            category="Student",
            notes="CS Major"
        )
        self.assertTrue(ok)
        self.assertIsNotNone(contact)
        self.assertEqual(len(self.manager.contacts), 1)

        # Duplicate email check
        ok2, msg2, _ = self.manager.add_contact(
            name="Alice Duplicate",
            phone="+1-555-0199",
            email="asmith@campus.edu"
        )
        self.assertFalse(ok2)

        # Search Contact
        results = self.manager.search_contacts("Alice")
        self.assertEqual(len(results), 1)

        # Edit Contact
        ok_edit, _, updated = self.manager.edit_contact(contact.id, {"phone": "+1-555-0200"})
        self.assertTrue(ok_edit)
        self.assertEqual(updated.phone, "+1-555-0200")

        # Delete Contact
        ok_del, _ = self.manager.delete_contact(contact.id)
        self.assertTrue(ok_del)
        self.assertEqual(len(self.manager.contacts), 0)

    def test_storage_persistence(self):
        # Add contacts & save
        self.manager.add_contact("Bob Jones", "+1-555-0300", "bjones@campus.edu", "Academic")
        self.storage.save_json(self.manager.contacts)
        self.storage.save_csv(self.manager.contacts)

        # Reload from JSON
        loaded_json, err1 = self.storage.load_json()
        self.assertIsNone(err1)
        self.assertEqual(len(loaded_json), 1)
        self.assertEqual(loaded_json[0].name, "Bob Jones")

        # Reload from CSV
        loaded_csv, err2 = self.storage.load_csv()
        self.assertIsNone(err2)
        self.assertEqual(len(loaded_csv), 1)
        self.assertEqual(loaded_csv[0].email, "bjones@campus.edu")

    def test_analytics_and_report_export(self):
        self.manager.add_contact("Dr. Vance", "+1-555-0101", "evance@campus.edu", "Academic")
        self.manager.add_contact("Marcus Chen", "+1-555-0102", "mchen@campus.edu", "Student")
        
        analytics = ContactAnalytics(self.manager.contacts)
        metrics = analytics.generate_summary_metrics()
        self.assertEqual(metrics["total_contacts"], 2)
        self.assertEqual(metrics["edu_domain_contacts"], 2)

        md_file = os.path.join(self.test_dir, "test_summary.md")
        csv_file = os.path.join(self.test_dir, "test_summary.csv")

        self.assertTrue(analytics.export_markdown_report(md_file))
        self.assertTrue(analytics.export_csv_summary(csv_file))
        self.assertTrue(os.path.exists(md_file))
        self.assertTrue(os.path.exists(csv_file))

if __name__ == "__main__":
    unittest.main()
